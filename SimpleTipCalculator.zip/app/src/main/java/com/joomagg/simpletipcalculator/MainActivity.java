package com.joomagg.simpletipcalculator;

import android.content.DialogInterface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /* initialize variables of views */
        RadioButton button[] = new RadioButton[3];
        EditText others;

        button[0] = (RadioButton)findViewById(R.id.button1);    // 15% button
        button[1] = (RadioButton)findViewById(R.id.button2);    // 20% button
        button[2] = (RadioButton)findViewById(R.id.button3);    // others button
        Button cal_button = (Button)findViewById(R.id.button4); // calculate button
        others = (EditText)findViewById(R.id.others);   // others edittext

        // if check button 1, 2, 3, edittext named others lose focus
        for (int i=0; i<2; i=i+1) {
            button[i].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    EditText others = (EditText) findViewById(R.id.others);
                    others.setText("");
              //      others.clearFocus();
                    others.setVisibility(View.INVISIBLE);   // if button 1, 2 clicked, edittext is invisible
                }
            });
        }
        // if check button3, edittext named others get focus
        button[2].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText others = (EditText) findViewById(R.id.others);
                others.setVisibility(View.VISIBLE);
                others.requestFocus();
            }
        });

        // calculate
        cal_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try
                {
                    double totalpay, tippay;
                    RadioButton rb[] = new RadioButton[3];
                    rb[0] = (RadioButton)findViewById(R.id.button1);
                    rb[1] = (RadioButton)findViewById(R.id.button2);
                    rb[2] = (RadioButton)findViewById(R.id.button3);

                    EditText amount = (EditText)findViewById(R.id.editText);
                    EditText others = (EditText)findViewById(R.id.others);
                    RadioGroup rg = (RadioGroup) findViewById(R.id.radio);


                    // if 15% button clicked
                    if (rg.getCheckedRadioButtonId() == rb[0].getId()) {
                        totalpay = Double.parseDouble(amount.getText().toString());
                        tippay = totalpay * 0.15;
                        totalpay = totalpay + tippay;
                    }
                    // if 20% button clicked
                    else if (rg.getCheckedRadioButtonId() == rb[1].getId()) {
                        totalpay = Double.parseDouble(amount.getText().toString());
                        tippay = totalpay * 0.2;
                        totalpay = totalpay + tippay;
                    }
                    // if others button clicked
                    else if (rg.getCheckedRadioButtonId() == rb[2].getId())
                    {
                        // if no values in edittext
                        if (others.getText().toString().isEmpty())
                            throw (new Exception("No Value Has Typed"));
                        totalpay = Double.parseDouble(amount.getText().toString());
                        tippay = totalpay * Double.parseDouble(others.getText().toString())/100;
                        totalpay = totalpay + tippay;
                    }
                    // if no button clicked
                    else {
                        throw (new Exception("No Button Has Checked"));
                    }
                    Toast.makeText(MainActivity.this, "Total pay: "+totalpay+"\nTip pay: "+tippay, Toast.LENGTH_SHORT).show();
                }
                catch (Exception e)
                {
                    Toast.makeText(MainActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
